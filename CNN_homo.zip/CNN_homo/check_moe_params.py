#!/usr/bin/env python3
"""
检查MoE模型中所有参数的训练状态
"""

import torch
import torch.nn as nn
from models.moe_model import MixtureOfExperts

def check_moe_parameters():
    """检查MoE模型中所有参数的训练状态"""
    
    print("🔍 检查MoE模型参数训练状态")
    print("="*60)
    
    # 创建MoE模型实例
    model = MixtureOfExperts(
        base_model_name='resnet50',
        num_colon_classes=7,
        num_ugi_classes=10, 
        num_colon_disease_classes=4,
        num_ugi_disease_classes=6,
        use_attention_gate=True
    )
    
    print(f"📊 模型结构信息:")
    print(f"  - 专家数量: {model.num_experts}")
    print(f"  - Top-K 选择: {model.top_k}")
    print(f"  - 特征维度: {model.feature_dim}")
    
    # 统计各组件参数
    total_params = 0
    trainable_params = 0
    
    print(f"\n🧠 各组件参数详情:")
    
    # 1. 编码器参数
    encoder_params = sum(p.numel() for p in model.encoder.parameters())
    encoder_trainable = sum(p.numel() for p in model.encoder.parameters() if p.requires_grad)
    total_params += encoder_params
    trainable_params += encoder_trainable
    print(f"  编码器 (Encoder):")
    print(f"    - 总参数: {encoder_params:,}")
    print(f"    - 可训练: {encoder_trainable:,}")
    print(f"    - 训练状态: {'✅ 全部训练' if encoder_trainable == encoder_params else '⚠️ 部分冻结'}")
    
    # 2. 查看编码器的前几层是否被冻结
    frozen_layers = []
    for name, param in model.encoder.named_parameters():
        if not param.requires_grad:
            frozen_layers.append(name)
    
    if frozen_layers:
        print(f"    - 冻结层数: {len(frozen_layers)}")
        print(f"    - 冻结层示例: {frozen_layers[:3]}...")
    
    # 3. 专家网络参数
    print(f"\n  专家网络 (Experts):")
    for i, expert in enumerate(model.experts):
        expert_params = sum(p.numel() for p in expert.parameters())
        expert_trainable = sum(p.numel() for p in expert.parameters() if p.requires_grad)
        total_params += expert_params
        trainable_params += expert_trainable
        print(f"    - 专家 {i+1}: {expert_params:,} 参数 ({'✅ 训练' if expert_trainable == expert_params else '❌ 冻结'})")
    
    experts_total = sum(sum(p.numel() for p in expert.parameters()) for expert in model.experts)
    experts_trainable = sum(sum(p.numel() for p in expert.parameters() if p.requires_grad) for expert in model.experts)
    print(f"    - 专家网络总计: {experts_total:,} 参数")
    print(f"    - 专家可训练: {experts_trainable:,} 参数")
    
    # 4. 门控网络参数
    gate_params = sum(p.numel() for p in model.gate.parameters())
    gate_trainable = sum(p.numel() for p in model.gate.parameters() if p.requires_grad)
    total_params += gate_params
    trainable_params += gate_trainable
    print(f"\n  门控网络 (Gate):")
    print(f"    - 总参数: {gate_params:,}")
    print(f"    - 可训练: {gate_trainable:,}")
    print(f"    - 训练状态: {'✅ 训练' if gate_trainable == gate_params else '❌ 冻结'}")
    
    # 5. 分类器参数
    classifiers = [
        ('结肠部位分类器', model.colon_classifier),
        ('胃镜部位分类器', model.ugi_classifier), 
        ('结肠疾病分类器', model.colon_disease_classifier),
        ('胃镜疾病分类器', model.ugi_disease_classifier)
    ]
    
    print(f"\n  任务分类器 (Classifiers):")
    classifier_total = 0
    classifier_trainable = 0
    
    for name, classifier in classifiers:
        clf_params = sum(p.numel() for p in classifier.parameters())
        clf_trainable = sum(p.numel() for p in classifier.parameters() if p.requires_grad)
        classifier_total += clf_params
        classifier_trainable += clf_trainable
        total_params += clf_params
        trainable_params += clf_trainable
        print(f"    - {name}: {clf_params:,} 参数 ({'✅ 训练' if clf_trainable == clf_params else '❌ 冻结'})")
    
    print(f"    - 分类器总计: {classifier_total:,} 参数")
    print(f"    - 分类器可训练: {classifier_trainable:,} 参数")
    
    # 总体统计
    print(f"\n📈 总体参数统计:")
    print(f"  - 模型总参数: {total_params:,}")
    print(f"  - 可训练参数: {trainable_params:,}")
    print(f"  - 参数训练比例: {trainable_params/total_params*100:.1f}%")
    
    # 验证所有专家都会被训练
    print(f"\n🎯 专家网络训练验证:")
    print(f"  - 专家网络数量: {len(model.experts)}")
    
    all_experts_trainable = True
    for i, expert in enumerate(model.experts):
        expert_trainable_count = sum(1 for p in expert.parameters() if p.requires_grad)
        expert_total_count = sum(1 for p in expert.parameters())
        
        if expert_trainable_count != expert_total_count:
            all_experts_trainable = False
            print(f"  ⚠️ 专家 {i+1}: {expert_trainable_count}/{expert_total_count} 层可训练")
        else:
            print(f"  ✅ 专家 {i+1}: 所有 {expert_total_count} 层都可训练")
    
    # 门控网络训练验证
    gate_trainable_count = sum(1 for p in model.gate.parameters() if p.requires_grad)
    gate_total_count = sum(1 for p in model.gate.parameters())
    print(f"  ✅ 门控网络: {gate_trainable_count}/{gate_total_count} 层可训练")
    
    print(f"\n🏆 结论:")
    if all_experts_trainable and gate_trainable_count == gate_total_count:
        print("  ✅ 所有专家网络和门控网络都参与训练!")
        print("  ✅ MoE架构的核心组件训练状态正常!")
    else:
        print("  ⚠️ 存在部分专家或门控网络参数未参与训练")
    
    return model, total_params, trainable_params

if __name__ == '__main__':
    model, total, trainable = check_moe_parameters()